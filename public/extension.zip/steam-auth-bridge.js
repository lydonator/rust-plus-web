// Steam Auth Bridge - Minimal service worker
// The declarativeNetRequest rules in rules.json do all the heavy lifting
// This worker just exists to satisfy the manifest requirement

console.log('[Steam Auth Bridge] Service worker loaded');
console.log('[Steam Auth Bridge] declarativeNetRequest rules are active');
console.log('[Steam Auth Bridge] Listening for localhost auth callbacks...');
